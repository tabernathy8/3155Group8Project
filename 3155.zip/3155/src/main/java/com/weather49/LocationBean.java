/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.weather49;
import org.slf4j.*;
import com.google.maps.*;
import com.google.maps.errors.*;
import com.google.maps.internal.ratelimiter.*;
import com.google.maps.model.*;
import com.google.gson.*;
import java.io.IOException;
public class LocationBean {
    GeoApiContext context = new GeoApiContext.Builder()
            .apiKey("AIzaSyA5eoidUhE1vkdPF5_j63z7BxeLWZs4jYE")
                .build();
    String location;
    public LocationBean(String address)
    {
        this.location = address;
    }
    public void setLocation(String address)
    {
        this.location = address;
    }
    public String getAddress()
    {
        return location;
    }
    public double[] getResults() throws IOException
    {
        try{
            GeocodingResult[] results = GeocodingApi.geocode(context, getAddress()).await();
            double[] latlng = new double[2];
            latlng[0] = results[0].geometry.location.lat;
            latlng[1] = results[0].geometry.location.lng;
            return latlng;
        }catch(ApiException e){
            e.toString();
        }catch(InterruptedException e){
            e.toString();
        }catch(IOException x){
            x.toString();
        }
        return null;
        
        
    }
    
}
