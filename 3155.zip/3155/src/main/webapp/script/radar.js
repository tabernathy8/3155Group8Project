/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var openWeatherMapKey = "566c5f6f796270ca04bd8c5031da5847";

